namespace MetascoreWeb.Models;

public class PredictResultViewModel
{
    public PredictInput Input { get; set; } = new();
    public double? Prediction { get; set; }
    public string? Error { get; set; }
}
