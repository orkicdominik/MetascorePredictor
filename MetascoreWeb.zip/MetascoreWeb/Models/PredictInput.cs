using System.ComponentModel.DataAnnotations;

namespace MetascoreWeb.Models;

public class PredictInput
{
    [Required]
    [RegularExpression(@"^\d{4}-\d{2}-\d{2}$", ErrorMessage = "Upiši datum u formatu YYYY-MM-DD.")]
    public string ReleaseDate { get; set; } = "2025-01-01";

    [Range(1, 200)]
    public double SeasonCount { get; set; } = 1;

    [Range(1, 400)]
    public double Duration { get; set; } = 45;

    [Range(0, 50000)]
    public double Metascore_Count { get; set; } = 10;

    [Range(0, 100)]
    public double Userscore { get; set; } = 70;

    [Range(0, 5000000)]
    public double Userscore_Count { get; set; } = 100;

    [Required]
    public string Rating { get; set; } = "TV-MA";

    [Required]
    public string Genres { get; set; } = "Drama";
}
