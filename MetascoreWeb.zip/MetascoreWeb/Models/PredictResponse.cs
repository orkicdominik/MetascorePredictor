using System.Text.Json;

namespace MetascoreWeb.Models;

public static class PredictResponse
{
    public static double ExtractScoredLabel(string body)
    {
        using var doc = JsonDocument.Parse(body);
        var root = doc.RootElement;

        var scored =
            root.GetProperty("Results")
                .GetProperty("WebServiceOutput0")[0]
                .GetProperty("Scored Labels");

        return scored.GetDouble();
    }
}
