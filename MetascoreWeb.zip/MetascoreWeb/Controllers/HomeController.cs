using Microsoft.AspNetCore.Mvc;
using MetascoreWeb.Models;
using MetascoreWeb.Services;
using System.ComponentModel.DataAnnotations;

namespace MetascoreWeb.Controllers;

public class HomeController : Controller
{
    private readonly IAzureMlService _ml;

    public HomeController(IAzureMlService ml) => _ml = ml;

    [HttpGet]
    public IActionResult Index()
        => View(new PredictResultViewModel { Input = new PredictInput() });

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Index(PredictInput input)
    {
        var vm = new PredictResultViewModel { Input = input };

        if (!ModelState.IsValid)
        {
            vm.Error = "Validation unsuccessful";
            return View(vm);
        }

        try { vm.Prediction = await _ml.PredictAsync(input); }
        catch (Exception ex) { vm.Error = ex.Message; }

        return View(vm);
    }

    // ✅ Compare GET vraća List<PredictResultViewModel>
    [HttpGet]
    public IActionResult Compare()
        => View(new List<PredictResultViewModel>
        {
            new() { Input = new PredictInput() },
            new() { Input = new PredictInput() }
        });

    // ✅ Compare POST prima List<PredictInput> inputs i vraća List<PredictResultViewModel>
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Compare(List<PredictInput> inputs)
    {
        inputs ??= new List<PredictInput>();

        var results = inputs
            .Select(i => new PredictResultViewModel { Input = i })
            .ToList();

        for (int i = 0; i < results.Count; i++)
        {
            var item = results[i];

            // Validacija po itemu
            var ctx = new ValidationContext(item.Input);
            var val = new List<ValidationResult>();
            if (!Validator.TryValidateObject(item.Input, ctx, val, true))
            {
                item.Error = "Validation unsuccessful.";
                continue;
            }

            try { item.Prediction = await _ml.PredictAsync(item.Input); }
            catch (Exception ex) { item.Error = ex.Message; }
        }

        return View(results);
    }

    public IActionResult Privacy() => View();
}
