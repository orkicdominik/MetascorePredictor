using Microsoft.AspNetCore.Mvc;

namespace MetascoreWeb.Controllers;

public class HistoryController : Controller
{
    [HttpGet]
    public IActionResult Index() => View();
}
