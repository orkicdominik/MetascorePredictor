using MetascoreWeb.Models;

namespace MetascoreWeb.Services;

public interface IAzureMlService
{
    Task<double> PredictAsync(PredictInput input);
}
