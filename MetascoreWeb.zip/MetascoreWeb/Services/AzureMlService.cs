using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using MetascoreWeb.Models;

namespace MetascoreWeb.Services;

public class AzureMlService : IAzureMlService
{
    private readonly HttpClient _http;
    private readonly IConfiguration _cfg;

    public AzureMlService(HttpClient http, IConfiguration cfg)
    {
        _http = http;
        _cfg = cfg;
    }

    public async Task<double> PredictAsync(PredictInput input)
    {
        var url = _cfg["AzureMl:EndpointUrl"] ?? "";
        var key = _cfg["AzureMl:ApiKey"] ?? "";

        if (string.IsNullOrWhiteSpace(url)) throw new Exception("AzureMl:EndpointUrl nije postavljen.");
        if (string.IsNullOrWhiteSpace(key)) throw new Exception("AzureMl:ApiKey nije postavljen.");

        // hard-code metascore=0 (da ga korisnik ne šalje)
        var payload = new
        {
            Inputs = new
            {
                input1 = new[]
                {
                    new Dictionary<string, object?>
                    {
                        ["releaseDate"] = input.ReleaseDate,
                        ["seasonCount"] = input.SeasonCount,
                        ["duration"] = input.Duration,
                        ["metascore"] = 0, // ✅ hardcode
                        ["metascore_count"] = input.Metascore_Count,
                        ["userscore"] = input.Userscore,
                        ["userscore_count"] = input.Userscore_Count,
                        ["rating"] = input.Rating,
                        ["genres"] = input.Genres
                    }
                }
            },
            GlobalParameters = new { }
        };

        var json = JsonSerializer.Serialize(payload);
        using var req = new HttpRequestMessage(HttpMethod.Post, url);
        req.Headers.Authorization = new AuthenticationHeaderValue("Bearer", key);
        req.Headers.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        req.Content = new StringContent(json, Encoding.UTF8, "application/json");

        using var res = await _http.SendAsync(req);
        var body = await res.Content.ReadAsStringAsync();

        if (!res.IsSuccessStatusCode)
            throw new Exception($"Azure ML error: {(int)res.StatusCode} {res.ReasonPhrase}\n{body}");

        return PredictResponse.ExtractScoredLabel(body);
    }
}
