﻿(function () {
  // ---------- Single: spinner ----------
  const form = document.getElementById("predictForm");
  const spinner = document.getElementById("spinner");
  const waitingText = document.getElementById("waitingText");
  const btn = document.getElementById("btnPredict");

  if (form) {
    form.addEventListener("submit", () => {
      spinner?.classList.remove("d-none");
      waitingText?.classList.remove("d-none");
      btn?.setAttribute("disabled", "disabled");
    });
  }

  // ---------- Auto-save single ----------
  if (window.__historyInput && typeof window.__score === "number" && window.HistoryStore) {
    try {
      window.HistoryStore.saveItem(window.__historyInput, window.__score);
    } catch {}
  }

  // ---------- Single badge ----------
  if (typeof window.__score === "number") {
    const s = Math.max(0, Math.min(100, window.__score));
    const badge = document.getElementById("scoreBadge");
    if (badge) {
      badge.classList.remove("bg-danger", "bg-warning", "bg-success", "text-dark");
      if (s < 40) { badge.classList.add("bg-danger"); badge.textContent = "Bad"; }
      else if (s < 70) { badge.classList.add("bg-warning", "text-dark"); badge.textContent = "Medium"; }
      else { badge.classList.add("bg-success"); badge.textContent = "Great"; }
    }
  }

  // ---------- Single gauge ----------
  if (typeof window.__score === "number" && document.getElementById("gauge")) {
    const score = Math.max(0, Math.min(100, window.__score));
    const rest = 100 - score;

    new Chart(document.getElementById("gauge"), {
      type: "doughnut",
      data: { labels: ["Score", "Rest"], datasets: [{ data: [score, rest], borderWidth: 0, hoverOffset: 0 }] },
      options: { cutout: "75%", plugins: { legend: { display: false }, tooltip: { enabled: false } } }
    });
  }

  // ---------- Compare: add/remove + renumber ----------
  const rows = document.getElementById("rows");
  const btnAdd = document.getElementById("btnAdd");
  const compareForm = document.getElementById("compareForm");
  const spinnerCompare = document.getElementById("spinnerCompare");
  const btnPredictAll = document.getElementById("btnPredictAll");

  function renumber() {
    if (!rows) return;
    const cards = rows.querySelectorAll(".compare-card");
    cards.forEach((card, i) => {
      const title = card.querySelector(".fw-semibold");
      if (title) title.textContent = `Show #${i + 1}`;

      // rename input names: inputs[0].X ...
      card.querySelectorAll("input").forEach(inp => {
        const name = inp.getAttribute("name") || "";
        inp.setAttribute("name", name.replace(/inputs\[\d+\]\./, `inputs[${i}].`));
      });
    });
  }

  window.removeCard = function (btn) {
    btn.closest(".compare-card")?.remove();
    renumber();
  };

  if (btnAdd && rows) {
    btnAdd.addEventListener("click", () => {
      const i = rows.querySelectorAll(".compare-card").length;
      const html = `
      <div class="card glass shadow-sm rounded-4 compare-card">
        <div class="card-body p-4">
          <div class="d-flex justify-content-between align-items-center mb-3">
            <div class="fw-semibold text-white">Show #${i + 1}</div>
            <button type="button" class="btn btn-sm btn-outline-danger rounded-4" onclick="removeCard(this)">Remove</button>
          </div>

          <div class="row g-3">
            <div class="col-md-3">
              <label class="form-label text-light">ReleaseDate</label>
              <input class="form-control soft" name="inputs[${i}].ReleaseDate" value="2025-01-01" />
            </div>
            <div class="col-md-2">
              <label class="form-label text-light">Seasons</label>
              <input class="form-control soft" name="inputs[${i}].SeasonCount" type="number" step="1" value="1" />
            </div>
            <div class="col-md-2">
              <label class="form-label text-light">Duration</label>
              <input class="form-control soft" name="inputs[${i}].Duration" type="number" step="1" value="45" />
            </div>
            <div class="col-md-2">
              <label class="form-label text-light">Metascore count</label>
              <input class="form-control soft" name="inputs[${i}].Metascore_Count" type="number" step="1" value="10" />
            </div>
            <div class="col-md-1">
              <label class="form-label text-light">Userscore</label>
              <input class="form-control soft" name="inputs[${i}].Userscore" type="number" step="0.1" value="70" />
            </div>
            <div class="col-md-2">
              <label class="form-label text-light">Userscore count</label>
              <input class="form-control soft" name="inputs[${i}].Userscore_Count" type="number" step="1" value="100" />
            </div>

            <div class="col-md-3">
              <label class="form-label text-light">Rating</label>
              <input class="form-control soft" name="inputs[${i}].Rating" value="TV-MA" />
            </div>
            <div class="col-md-9">
  <label class="form-label text-light">Genres</label>

  <input type="hidden" class="genresHidden" name="inputs[${i}].Genres" value="Drama" />

  <div class="genreWrap d-grid gap-2"></div>

  <div class="d-flex gap-2 mt-2">
    <button type="button" class="btn btn-outline-primary rounded-4 btnAddGenre">+ Add genre</button>
    <button type="button" class="btn btn-outline-danger rounded-4 btnClearGenres">Clear</button>
  </div>

  
</div>

          </div>
        </div>
      </div>`;
      rows.insertAdjacentHTML("beforeend", html);
      const last = rows.querySelector(".compare-card:last-child");
      if (last) initCompareCard(last);

      renumber();
    });
  }

  if (compareForm) {
    compareForm.addEventListener("submit", () => {
      spinnerCompare?.classList.remove("d-none");
      btnPredictAll?.setAttribute("disabled", "disabled");
    });
  }

  // ---------- Compare: render chart + save all to history ----------
  if (Array.isArray(window.__compareResults) && window.__compareResults.length) {
    const labels = [];
    const values = [];

    window.__compareResults.forEach(x => {
      labels.push(`Show #${x.idx}`);
      values.push(x.prediction ?? null);

      if (x.prediction != null && window.HistoryStore) {
        try { window.HistoryStore.saveItem(x.input, x.prediction); } catch {}
      }
    });

    const canvas = document.getElementById("compareChart");
    if (canvas) {
      new Chart(canvas, {
        type: "bar",
        data: { labels, datasets: [{ label: "Predicted metascore", data: values }] },
        options: {
          plugins: { legend: { display: false } },
          scales: { y: { min: 0, max: 100 } }
        }
      });
    }
  }

  // ---------- History page renderer ----------
  const historyList = document.getElementById("historyList");
  if (historyList && window.HistoryStore) {
    const sortBy = document.getElementById("sortBy");
    const pageSizeSel = document.getElementById("pageSize");
    const btnPrev = document.getElementById("btnPrev");
    const btnNext = document.getElementById("btnNext");
    const pageInfo = document.getElementById("pageInfo");
    const empty = document.getElementById("historyEmpty");
    const btnClearAll = document.getElementById("btnClearAll");

    const statAvg = document.getElementById("statAvg");
    const statMin = document.getElementById("statMin");
    const statMax = document.getElementById("statMax");

    let page = 1;

    function computeStats(arr) {
      if (!arr.length) {
        statAvg.textContent = "—";
        statMin.textContent = "—";
        statMax.textContent = "—";
        return;
      }
      const vals = arr.map(x => Number(x.prediction)).filter(v => Number.isFinite(v));
      const min = Math.min(...vals);
      const max = Math.max(...vals);
      const avg = vals.reduce((a,b) => a+b, 0) / vals.length;

      statAvg.textContent = avg.toFixed(2);
      statMin.textContent = min.toFixed(2);
      statMax.textContent = max.toFixed(2);
    }

    function sortArr(arr) {
      const s = sortBy?.value || "new";
      const copy = [...arr];

      if (s === "new") copy.sort((a,b) => (b.createdAt||"").localeCompare(a.createdAt||""));
      if (s === "old") copy.sort((a,b) => (a.createdAt||"").localeCompare(b.createdAt||""));
      if (s === "scoreDesc") copy.sort((a,b) => (b.prediction ?? 0) - (a.prediction ?? 0));
      if (s === "scoreAsc") copy.sort((a,b) => (a.prediction ?? 0) - (b.prediction ?? 0));

      return copy;
    }

    function badgeClass(score) {
      if (score < 40) return "bg-danger";
      if (score < 70) return "bg-warning text-dark";
      return "bg-success";
    }

    function render() {
      const raw = window.HistoryStore.getAll();
      const arr = sortArr(raw);
      computeStats(arr);

      const pageSize = Number(pageSizeSel?.value || 10);
      const total = arr.length;
      const pages = Math.max(1, Math.ceil(total / pageSize));
      page = Math.min(page, pages);

      const start = (page - 1) * pageSize;
      const slice = arr.slice(start, start + pageSize);

      historyList.innerHTML = "";
      empty?.classList.toggle("d-none", total !== 0);

      slice.forEach(item => {
        const score = Math.max(0, Math.min(100, Number(item.prediction)));
        const html = `
          <div class="card glass rounded-4">
            <div class="card-body p-4">
              <div class="d-flex justify-content-between align-items-start gap-3">
                <div>
                  <div class="text-secondary small">${new Date(item.createdAt).toLocaleString()}</div>
                  <div class="d-flex align-items-center gap-2 mt-1">
                    <div class="h4 fw-bold text-white m-0">${score.toFixed(2)}</div>
                    <span class="badge rounded-pill ${badgeClass(score)} px-3 py-2">/100</span>
                  </div>
                </div>
                <button class="btn btn-sm btn-outline-danger rounded-4" data-del="${item.id}">Delete</button>
              </div>

              <hr class="border-secondary my-3" />

              <div class="row g-2 small">
                <div class="col-md-3 text-secondary">ReleaseDate</div><div class="col-md-3 text-white">${item.releaseDate}</div>
                <div class="col-md-3 text-secondary">Seasons</div><div class="col-md-3 text-white">${item.seasonCount}</div>

                <div class="col-md-3 text-secondary">Duration</div><div class="col-md-3 text-white">${item.duration}</div>
                <div class="col-md-3 text-secondary">Metascore count</div><div class="col-md-3 text-white">${item.metascore_count}</div>

                <div class="col-md-3 text-secondary">Userscore</div><div class="col-md-3 text-white">${item.userscore}</div>
                <div class="col-md-3 text-secondary">Userscore count</div><div class="col-md-3 text-white">${item.userscore_count}</div>

                <div class="col-md-3 text-secondary">Rating</div><div class="col-md-3 text-white">${item.rating}</div>
                <div class="col-md-3 text-secondary">Genres</div><div class="col-md-3 text-white">${item.genres}</div>
              </div>
            </div>
          </div>`;
        historyList.insertAdjacentHTML("beforeend", html);
      });

      pageInfo.textContent = `Page ${page}/${pages} · ${total} items`;
      btnPrev.disabled = page <= 1;
      btnNext.disabled = page >= pages;

      historyList.querySelectorAll("[data-del]").forEach(btn => {
        btn.addEventListener("click", () => {
          window.HistoryStore.remove(btn.getAttribute("data-del"));
          render();
        });
      });
    }

    sortBy?.addEventListener("change", () => { page = 1; render(); });
    pageSizeSel?.addEventListener("change", () => { page = 1; render(); });
    btnPrev?.addEventListener("click", () => { page--; render(); });
    btnNext?.addEventListener("click", () => { page++; render(); });

    btnClearAll?.addEventListener("click", () => {
      if (!confirm("Obrisati cijeli history?")) return;
      window.HistoryStore.clear();
      render();
    });

    render();
  }
    // ---------- Genres multi-select (Single + Compare) ----------
    const GENRES = ["Drama","Comedy","Crime","Action","Adventure","Romance","Horror","Thriller","Sci-Fi","Documentary"];

    function createGenreSelect(selected) {
      const sel = document.createElement("select");
      sel.className = "form-select soft genreSelect";
      sel.innerHTML = `
        <option value="">(choose)</option>
        ${GENRES.map(g => `<option value="${g}">${g}</option>`).join("")}
      `;
      if (selected) sel.value = selected;
      return sel;
    }
  
    function splitGenres(str) {
      if (!str) return [];
      return String(str)
        .split(",")
        .map(x => x.trim())
        .filter(Boolean);
    }
  
    function joinGenres(values) {
      const set = new Set(values.map(v => v.trim()).filter(Boolean));
      return Array.from(set).join(",");
    }
  
    // --- Single init ---
    const wrapSingle = document.getElementById("genreWrapSingle");
    const hiddenSingle = document.getElementById("Genres");
    const btnAddSingle = document.getElementById("btnAddGenreSingle");
    const btnClearSingle = document.getElementById("btnClearGenresSingle");
  
    function syncSingle() {
      if (!wrapSingle || !hiddenSingle) return;
      const vals = Array.from(wrapSingle.querySelectorAll("select"))
        .map(s => s.value)
        .filter(Boolean);
      hiddenSingle.value = joinGenres(vals);
    }
  
    function addSingleGenre(value) {
      if (!wrapSingle) return;
      const row = document.createElement("div");
      row.className = "d-flex gap-2";
  
      const sel = createGenreSelect(value);
      sel.addEventListener("change", syncSingle);
  
      const btnRemove = document.createElement("button");
      btnRemove.type = "button";
      btnRemove.className = "btn btn-outline-danger rounded-4";
      btnRemove.textContent = "Remove";
      btnRemove.addEventListener("click", () => { row.remove(); syncSingle(); });
  
      row.appendChild(sel);
      row.appendChild(btnRemove);
      wrapSingle.appendChild(row);
  
      syncSingle();
    }
  
    if (wrapSingle && hiddenSingle) {
      const initial = splitGenres(hiddenSingle.value);
      if (initial.length) initial.forEach(g => addSingleGenre(g));
      else addSingleGenre("Drama"); // default 1
      btnAddSingle?.addEventListener("click", () => addSingleGenre(""));
      btnClearSingle?.addEventListener("click", () => {
        wrapSingle.innerHTML = "";
        addSingleGenre("");
        syncSingle();
      });
    }
  
    // --- Compare init (per card) ---
    function initCompareCard(card) {
      const wrap = card.querySelector(".genreWrap");
      const hidden = card.querySelector(".genresHidden");
      const btnAdd = card.querySelector(".btnAddGenre");
      const btnClear = card.querySelector(".btnClearGenres");
      if (!wrap || !hidden) return;
  
      function sync() {
        const vals = Array.from(wrap.querySelectorAll("select")).map(s => s.value).filter(Boolean);
        hidden.value = joinGenres(vals);
      }
  
      function add(value) {
        const row = document.createElement("div");
        row.className = "d-flex gap-2";
  
        const sel = createGenreSelect(value);
        sel.addEventListener("change", sync);
  
        const rm = document.createElement("button");
        rm.type = "button";
        rm.className = "btn btn-outline-danger rounded-4";
        rm.textContent = "Remove";
        rm.addEventListener("click", () => { row.remove(); sync(); });
  
        row.appendChild(sel);
        row.appendChild(rm);
        wrap.appendChild(row);
        sync();
      }
  
      // init from hidden value
      wrap.innerHTML = "";
      const initial = splitGenres(hidden.value);
      if (initial.length) initial.forEach(g => add(g));
      else add("Drama");
  
      btnAdd?.addEventListener("click", () => add(""));
      btnClear?.addEventListener("click", () => {
        wrap.innerHTML = "";
        add("");
        sync();
      });
    }
  
    // init all existing compare cards
    document.querySelectorAll(".compare-card").forEach(initCompareCard);
  
    // if compare "Add show" adds new card HTML, init it after insertion
    // (tvoj postojeći btnAdd kod već radi insertAdjacentHTML; samo dodaj 2 linije nakon insertAdjacentHTML)
  
})();
