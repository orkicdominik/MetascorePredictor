(function () {
    const KEY = "metascore_history_v1";
  
    function safeParse(raw) {
      try { return raw ? JSON.parse(raw) : []; } catch { return []; }
    }
  
    window.HistoryStore = {
      getAll() {
        return safeParse(localStorage.getItem(KEY));
      },
      saveItem(input, prediction) {
        const item = {
          id: crypto?.randomUUID ? crypto.randomUUID() : String(Date.now()) + Math.random(),
          createdAt: new Date().toISOString(),
          releaseDate: input.releaseDate,
          seasonCount: Number(input.seasonCount),
          duration: Number(input.duration),
          metascore_count: Number(input.metascore_count),
          userscore: Number(input.userscore),
          userscore_count: Number(input.userscore_count),
          rating: input.rating,
          genres: input.genres,
          prediction: Number(prediction)
        };
  
        const arr = safeParse(localStorage.getItem(KEY));
        arr.unshift(item);                 // ✅ newest first
        if (arr.length > 500) arr.length = 500;
        localStorage.setItem(KEY, JSON.stringify(arr));
        return item;
      },
      remove(id) {
        const arr = safeParse(localStorage.getItem(KEY)).filter(x => x.id !== id);
        localStorage.setItem(KEY, JSON.stringify(arr));
      },
      clear() {
        localStorage.removeItem(KEY);
      }
    };
  })();
  